package main;
import database.OracleBDBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
import java.sql.ResultSet;
import java.sql.Statement;

public class StudentManagement {
    public static void addStudent() {
        try (Connection con = OracleBDBConnection.getConnection();
             Scanner scanner = new Scanner(System.in)) {

            System.out.print("Enter Student ID: ");
            int id = scanner.nextInt();
            scanner.nextLine();

            System.out.print("Enter Student Name: ");
            String name = scanner.nextLine();

            System.out.print("Enter Age: ");
            int age = scanner.nextInt();
            scanner.nextLine();

            System.out.print("Enter Grade: ");
            String grade = scanner.nextLine();

            String query = "INSERT INTO students (id, name, age, grade) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, id);
            stmt.setString(2, name);
            stmt.setInt(3, age);
            stmt.setString(4, grade);

            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("✅ Student added successfully!");
            } else {
                System.out.println("❌ Failed to add student.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void displayStudents() {
        try (Connection conn = OracleBDBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM students")) {

            System.out.println("\nStudent List:");
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id") +
                                   ", Name: " + rs.getString("name") +
                                   ", Age: " + rs.getInt("age") +
                                   ", Grade: " + rs.getString("grade"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void searchStudent() {
        try (Connection conn = OracleBDBConnection.getConnection();
             Scanner scanner = new Scanner(System.in)) {

            System.out.print("Enter Student ID to search: ");
            int studentId = scanner.nextInt();

            String query = "SELECT * FROM students WHERE id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(query)) {
                pstmt.setInt(1, studentId);
                ResultSet rs = pstmt.executeQuery();

                if (rs.next()) {
                    System.out.println("\nStudent Found:");
                    System.out.println("ID: " + rs.getInt("id") +
                                       ", Name: " + rs.getString("name") +
                                       ", Age: " + rs.getInt("age") +
                                       ", Grade: " + rs.getString("grade"));
                } else {
                    System.out.println("No student found with ID: " + studentId);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void updateStudent() {
        try (Connection conn = OracleBDBConnection.getConnection();
             Scanner scanner = new Scanner(System.in)) {

            System.out.print("Enter Student ID to update: ");
            int studentId = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            System.out.print("Enter new name: ");
            String newName = scanner.nextLine();

            System.out.print("Enter new age: ");
            int newAge = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            System.out.print("Enter new grade: ");
            String newGrade = scanner.nextLine();

            String query = "UPDATE students SET name = ?, age = ?, grade = ? WHERE id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(query)) {
                pstmt.setString(1, newName);
                pstmt.setInt(2, newAge);
                pstmt.setString(3, newGrade);
                pstmt.setInt(4, studentId);

                int rowsUpdated = pstmt.executeUpdate();
                if (rowsUpdated > 0) {
                    System.out.println("✅ Student updated successfully!");
                } else {
                    System.out.println("❌ No student found with ID: " + studentId);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void deleteStudent() {
        try (Connection conn = OracleBDBConnection.getConnection();
             Scanner scanner = new Scanner(System.in)) {

            System.out.print("Enter Student ID to delete: ");
            int studentId = scanner.nextInt();

            String query = "DELETE FROM students WHERE id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(query)) {
                pstmt.setInt(1, studentId);

                int rowsDeleted = pstmt.executeUpdate();
                if (rowsDeleted > 0) {
                    System.out.println("✅ Student deleted successfully!");
                } else {
                    System.out.println("❌ No student found with ID: " + studentId);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("enter the no of operations=");
        int opt=scanner.nextInt();
        while (opt!=0) {  
            System.out.println("\n📌 Student Management System");
            System.out.println("1️⃣ Add Student");
            System.out.println("2️⃣ Update Student");
            System.out.println("3️⃣ Delete Student");
            System.out.println("4️⃣ Search Student");
            System.out.println("5️⃣ Display All Students");
            // Ensure input is an integer
            if (!scanner.hasNextInt()) {
                System.out.println("❌ Invalid input! Please enter a number.");
                scanner.nextInt(); // Clear invalid input
                continue; // Restart loop
            }

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            opt--;
            switch (choice) {
                case 1:
                    addStudent();
                    break;
                case 2:
                    updateStudent();
                    break;
                case 3:
                    deleteStudent();
                    break;
                case 4:
                    searchStudent();
                    break;
                case 5:
                    displayStudents();
                    break;
                case 6:
                    System.out.println("✅ Exiting... Goodbye!");
                    scanner.close(); // Close scanner on exit
                    return;  
                default:
                    System.out.println("❌ Invalid choice! Try again.");
            }
        }
    }}