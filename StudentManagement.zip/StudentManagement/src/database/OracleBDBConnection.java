package database;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class OracleBDBConnection {
    private static final String URL = "jdbc:oracle:thin:@localhost:1521:xe"; // Change if needed
    private static final String USER = "SYSTEM"; // Change this
    private static final String PASSWORD = "mokshi123"; // Change this

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}